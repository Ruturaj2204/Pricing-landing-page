All the Text Material is Here -


Color Codes :-
    Primary Color = #B31312;
    Secondary Color = #002c3e;
    Font Color = #0c0c0c;
    Background Color = #f8f8f8;
    Bg_color = #d5cdd3


Fonts Used :-
    1. Poppins
    2. Merienda


Home Page Paragraph :-
    We provide high quality fashion items for men, women and children. Our products are timeless, unique and stylish. We offer a wide range of minimalist print products in different styles and sizes.
    Our mission is to become the go-to store for customers who are looking for high quality fashion products. With our products being affordable and highly accessible, we believe that we can help our customers create and express their own style


Footer Tagline :-
    Copyright &#xa9; All Rights Reserved
